<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Models\StaffAvailability;
use App\Http\Controllers\Controller;
use App\Services\StaffAvailabilityService;
use App\Http\Requests\StaffAvailability\CreateStaffAvailabilityRequest;
use App\Http\Requests\StaffAvailability\UpdateStaffAvailabilityRequest;

class StaffAvailabilityController extends Controller
{
    protected $staffAvailabilityService;
    public function __construct(StaffAvailabilityService $staffAvailabilityService)
    {
        $this->middleware('permission:staff_availability.view', ['only' => ['index', 'show']]);
        $this->middleware('permission:staff_availability.create', ['only' => ['create', 'store']]);
        $this->middleware('permission:staff_availability.edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:staff_availability.delete', ['only' => ['destroy']]);
        
        $this->staffAvailabilityService = $staffAvailabilityService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CreateStaffAvailabilityRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(StaffAvailability $staffAvailability)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(StaffAvailability $staffAvailability)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateStaffAvailabilityRequest $request, StaffAvailability $staffAvailability)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(StaffAvailability $staffAvailability)
    {
        //
    }
}