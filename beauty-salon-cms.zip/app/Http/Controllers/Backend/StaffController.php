<?php

namespace App\Http\Controllers\Backend;

use App\Models\Staff;
use Illuminate\Http\Request;
use App\Services\StaffService;
use App\Http\Controllers\Controller;
use App\Http\Requests\Staff\CreateStaffRequest;
use App\Http\Requests\Staff\UpdateStaffRequest;

class StaffController extends Controller
{
    protected $staffService;
    public function __construct(StaffService $staffService)
    {
        $this->middleware('permission:staff.view', ['only' => ['index', 'show']]);
        $this->middleware('permission:staff.create', ['only' => ['create', 'store']]);
        $this->middleware('permission:staff.edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:staff.delete', ['only' => ['destroy']]);
        $this->staffService = $staffService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(CreateStaffRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Staff $staff)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Staff $staff)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateStaffRequest $request, Staff $staff)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Staff $staff)
    {
        //
    }

    public function changeStatus(Staff $staff){
         $this->staffService->changeStatus($staff);
         return redirect()->route('admin.staffs.index')->with('success', 'Staff status changed successfully');
    }
}