<?php

namespace App\Repositories\Backend;

use App\Models\Staff;
use App\Models\StaffAvailability;
use App\Repositories\BaseRepository;

class StaffAvailabilityRepository extends BaseRepository
{
    public function model()
    {
        return StaffAvailability::class;
    }
    
    public function create(array $data): StaffAvailability
    {

    }
    public function update(StaffAvailability $staffAvailability, array $data): StaffAvailability
    {

    }
    public function destroy(StaffAvailability $staffAvailability)
    {

    }

    public function isStaffAvailable(StaffAvailability $staffAvailability)
    {

    }

    public function getAvailabilityForStaff(Staff $staff)
    {
        
    }
}