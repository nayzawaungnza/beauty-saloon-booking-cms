<?php

namespace App\Repositories\Backend;

use App\Models\Staff;
use App\Repositories\BaseRepository;

class StaffRepository extends BaseRepository
{
    public function model()
    {
        return Staff::class;
    }
    
    public function getStaffBySlug($slug){
        return $this->model->where('slug', $slug)->first();
    }

    public function getStaffs(){
        return $this->model->all();
    }

    public function getStaffEloquent(){
        return $this->model;
    }
    public function destroy(Staff $staff){
        return $staff->delete();
    }

    public function changeStatus(Staff $staff){
        $staff->status = !$staff->status;
        $staff->save();
        return $staff;
    }

    public function update(Staff $staff, array $data){
        $staff->update($data);
        return $staff;
    }

    public function create(array $data){
        return $this->model->create($data);
    }
}