<?php

namespace App\Services\Interfaces;

use App\Models\Staff;
interface StaffServiceInterface
{
    public function getStaffs();
    public function getStaffBySlug($slug);
    public function getStaffEloquent();
    public function create(array $data);
    public function update(Staff $staff, array $data);
    public function changeStatus(Staff $staff);
    public function delete(Staff $staff);
}