<?php

namespace App\Services\Interfaces;

use App\Models\Staff;
use App\Models\StaffAvailability;

interface StaffAvailabilityServiceInterface
{
    public function create(array $data): StaffAvailability;
    public function update(StaffAvailability $staffAvailability, array $data): StaffAvailability;
    public function delete(StaffAvailability $staffAvailability);

    public function isStaffAvailable(StaffAvailability $staffAvailability);

    public function getAvailabilityForStaff(Staff $staff);
}