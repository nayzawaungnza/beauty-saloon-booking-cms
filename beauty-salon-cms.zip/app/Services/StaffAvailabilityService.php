<?php

namespace App\Services;

use Exception;
use App\Models\Staff;
use InvalidArgumentException;
use App\Models\StaffAvailability;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Repositories\Backend\StaffAvailabilityRepository;
use App\Services\Interfaces\StaffAvailabilityServiceInterface;

class StaffAvailabilityService implements StaffAvailabilityServiceInterface
{
    protected $staffAvailabilityRepository;
    /**
     * Create a new class instance.
     */
    public function __construct(StaffAvailabilityRepository $staffAvailabilityRepository)
    {
        $this->staffAvailabilityRepository = $staffAvailabilityRepository;
    }

    public function create(array $data): StaffAvailability
    {
         DB::beginTransaction();
        try {
            $staffAvailability = $this->staffAvailabilityRepository->create($data);
        } catch (Exception $exc) {
            DB::rollBack();
            Log::error('Staff Availability Creation Error:'.$exc->getMessage());
            throw new InvalidArgumentException('Unable to create staff availability');
        }
        DB::commit();
        return $staffAvailability;
        
    }
    public function update(StaffAvailability $staffAvailability, array $data): StaffAvailability
    {
        DB::beginTransaction();
        try {
            $staffAvailability = $this->staffAvailabilityRepository->update($staffAvailability, $data);
        } catch (Exception $exc) {
            DB::rollBack();
            Log::error('Staff Availability Update Error:'.$exc->getMessage());
            throw new InvalidArgumentException('Unable to update staff availability');
        }
        DB::commit();
        return $staffAvailability;
    }
    public function delete(StaffAvailability $staffAvailability)
    {
        DB::beginTransaction();
        try {
            $staffAvailability = $this->staffAvailabilityRepository->destroy($staffAvailability);
        } catch (Exception $exc) {
            DB::rollBack();
            Log::error('Staff Availability Deletion Error:'.$exc->getMessage());
            throw new InvalidArgumentException('Unable to delete staff availability');
        }
        DB::commit();
        return $staffAvailability;
    }

    public function isStaffAvailable(StaffAvailability $staffAvailability)
    {
        return $this->staffAvailabilityRepository->isStaffAvailable($staffAvailability);
    }

    public function getAvailabilityForStaff(Staff $staff)
    {
        return $this->staffAvailabilityRepository->getAvailabilityForStaff($staff);
    }
}