<?php

namespace App\Models;

use App\Traits\Uuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class StaffAvailability extends Model
{

    use HasFactory, Notifiable, Uuids, SoftDeletes;
    protected $fillable = [
        'staff_id',
        'day_of_week',
        'start_time',
        'end_time',
        'is_available',
        'effective_date',
        'created_by',
        'updated_by'
    ];

     protected $casts = [
        'day_of_week' => 'integer',
        'is_available' => 'boolean',
        'effective_date' => 'date',
        // Cast time fields if needed, often handled okay as strings but explicit is safer
        'start_time' => 'datetime:H:i:s',
        'end_time' => 'datetime:H:i:s',
    ];

    public function staff()
    {
        return $this->belongsTo(Staff::class);
    }

    public function createdBy()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updatedBy()
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}